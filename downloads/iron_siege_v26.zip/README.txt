IRON SIEGE - v26 (Contract Wars)

Extract this ZIP, then open iron_siege_v26.html in your browser.
No installation is required.

MISSION
Choose a contract, breach the foundry, and steal your target to start the
lockdown. Defeat the commander, break the perimeter gate, and extract.

CONTRACTS AND PROGRESS
Command Core and Reactor Theft are available immediately. Complete an
optional operation to unlock Weapons Shipment; extract to open Archive Raid.
Win three different contracts to uncover the hidden contract.

At 02:00 and 05:00, make lasting factory decisions. Every eighth level can
offer rare hardware for your equipment, with two rare slots per run.
Challenges unlock weapon patterns and paint. Each contract has five
Escalation tiers; extract at your highest available tier to open the next.
Pause shows your current decisions, rare equipment and the field manual.

CONTROLS
WASD or arrow keys: move
Space: dash
Weapons aim and fire automatically.
Touch: movement stick and DASH button
Pause: settings, field manual, equipment and complete radio intercept log

SAVES
Progress is saved in your browser. Use the same browser and game location
for future sessions. Moving the file or changing browsers may change which
save is available. Saves do not transfer between devices automatically.

FIELD OPERATIONS
The full-facility map outlines your current screen. Follow labeled operation
diamonds and screen-edge arrows with distance readouts. Events begin at 00:55
and recur roughly every minute. Complete three in one run for a weapon pattern.
