IRON SIEGE - v25 (Facility Operations)

Extract this ZIP, then open iron_siege_v25.html in your browser.
No installation is required.

MISSION
Breach the foundry, steal the core, survive the lockdown, defeat the Warden,
and break out through the perimeter gate to reach extraction.

CONTROLS
WASD or arrow keys: move
Space: dash
Weapons aim and fire automatically.
Touch: movement stick and DASH button
Pause: settings, field manual, and complete radio intercept log

SAVES
Progress is saved in your browser. Use the same browser and game location
for future sessions. Moving the file or changing browsers may change which
save is available. Saves do not transfer between devices automatically.

FIELD OPERATIONS
The full-facility map outlines your current screen. Follow labeled operation
diamonds and screen-edge arrows with distance readouts. Events begin at 00:55
and recur roughly every minute. Collect salvage, deliver power cells, or arm
a furnace charge and escape its blast ring, alongside existing operations.
